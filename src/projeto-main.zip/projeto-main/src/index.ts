
import { Cadastro } from "./CadastroView";
const cadastro1 = new Cadastro ("Maria," ,"mariacatarina@gmail.com, ","Santa Maria, ","Taquara, ", 51989198564  ,  1 );
console.log (cadastro1.ListarCadastro());